:- dynamic answered/2.
:- dynamic current_question/1.

% Reset all answers
reset_answers :-
    retractall(answered(_, _)),
    retractall(current_question(_)),
    asserta(current_question(1)).

% Personality dimensions
dimension('Introversion (I)', 'Extraversion (E)').
dimension('Intuition (N)', 'Sensing (S)').
dimension('Thinking (T)', 'Feeling (F)').
dimension('Judging (J)', 'Perceiving (P)').

% Personality types
personality_type('ISTJ', 'The Inspector - Practical, fact-minded, and dependable').
personality_type('ISFJ', 'The Protector - Warm, caring, and responsible').
personality_type('INFJ', 'The Counselor - Insightful, principled, and compassionate').
personality_type('INTJ', 'The Mastermind - Strategic, logical, and independent').
personality_type('ISTP', 'The Craftsman - Observant, flexible, and problem-solving').
personality_type('ISFP', 'The Composer - Gentle, artistic, and adaptable').
personality_type('INFP', 'The Healer - Idealistic, empathetic, and creative').
personality_type('INTP', 'The Architect - Analytical, innovative, and theoretical').
personality_type('ESTP', 'The Dynamo - Energetic, action-oriented, and spontaneous').
personality_type('ESFP', 'The Performer - Outgoing, fun-loving, and sociable').
personality_type('ENFP', 'The Champion - Enthusiastic, imaginative, and people-oriented').
personality_type('ENTP', 'The Visionary - Inventive, curious, and debate-loving').
personality_type('ESTJ', 'The Supervisor - Organized, traditional, and decisive').
personality_type('ESFJ', 'The Provider - Supportive, harmonious, and conscientious').
personality_type('ENFJ', 'The Teacher - Charismatic, empathetic, and persuasive').
personality_type('ENTJ', 'The Commander - Assertive, strategic, and goal-oriented').

% Questions 1-25 (I/E and S/N focused)
question(1, 'At a party, you tend to:', 
    'a) Talk to many people, including strangers (E)', 
    'b) Stick with close friends (I)', 
    'c) Observe quietly before joining in (I)', 
    'd) Leave early because it drains you (I)', 'E', 'I').

question(2, 'When learning something new, you:', 
    'a) Focus on concrete facts (S)', 
    'b) Look for underlying meanings (N)', 
    'c) Prefer hands-on experience (S)', 
    'd) Imagine future possibilities (N)', 'S', 'N').

question(3, 'Your ideal weekend involves:', 
    'a) Social events with many people (E)', 
    'b) Quiet time alone or with a close friend (I)', 
    'c) Trying something new and adventurous (E)', 
    'd) Relaxing at home with a book (I)', 'E', 'I').

question(4, 'When solving problems, you:', 
    'a) Follow step-by-step methods (S)', 
    'b) Brainstorm creative solutions (N)', 
    'c) Rely on past experiences (S)', 
    'd) Look for innovative approaches (N)', 'S', 'N').

question(5, 'In conversations, you usually:', 
    'a) Initiate discussions (E)', 
    'b) Wait for others to speak first (I)', 
    'c) Think carefully before responding (I)', 
    'd) Enjoy lively debates (E)', 'E', 'I').

question(6, 'You trust information that is:', 
    'a) Proven by experience (S)', 
    'b) Theoretically sound (N)', 
    'c) Based on tangible evidence (S)', 
    'd) Part of a bigger vision (N)', 'S', 'N').

question(7, 'When meeting someone new, you:', 
    'a) Initiate conversation easily (E)', 
    'b) Wait for them to approach you (I)', 
    'c) Observe them first (I)', 
    'd) Share personal stories quickly (E)', 'E', 'I').

question(8, 'You prefer work that involves:', 
    'a) Practical, concrete tasks (S)', 
    'b) Abstract concepts and ideas (N)', 
    'c) Clear, measurable results (S)', 
    'd) Exploring new possibilities (N)', 'S', 'N').

question(9, 'In your free time, you would rather:', 
    'a) Attend a large social gathering (E)', 
    'b) Have a deep conversation with one person (I)', 
    'c) Work on a personal project alone (I)', 
    'd) Try an exciting new activity with others (E)', 'E', 'I').

question(10, 'When making decisions, you:', 
    'a) Focus on the present reality (S)', 
    'b) Consider future implications (N)', 
    'c) Look at historical data (S)', 
    'd) Imagine various scenarios (N)', 'S', 'N').

% Questions 11-25 (T/F and J/P focused)
question(11, 'When making decisions, you prioritize:', 
    'a) Logic and objective analysis (T)', 
    'b) Personal values and harmony (F)', 
    'c) Practical consequences (T)', 
    'd) How it affects people emotionally (F)', 'T', 'F').

question(12, 'You prefer work environments that are:', 
    'a) Structured with clear deadlines (J)', 
    'b) Flexible and open-ended (P)', 
    'c) Fast-paced and dynamic (P)', 
    'd) Predictable and organized (J)', 'J', 'P').

question(13, 'In relationships, you value:', 
    'a) Deep emotional connections (F)', 
    'b) Intellectual compatibility (T)', 
    'c) Shared activities and fun (F)', 
    'd) Honest and direct communication (T)', 'F', 'T').

question(14, 'You feel most productive when:', 
    'a) Following a detailed plan (J)', 
    'b) Going with the flow (P)', 
    'c) Completing tasks ahead of schedule (J)', 
    'd) Having flexibility to change directions (P)', 'J', 'P').

question(15, 'When giving feedback, you tend to:', 
    'a) Focus on objective facts (T)', 
    'b) Consider people''s feelings (F)', 
    'c) Be blunt but fair (T)', 
    'd) Soften criticism with praise (F)', 'T', 'F').

question(16, 'Your approach to deadlines is:', 
    'a) Plan carefully to meet them early (J)', 
    'b) Work best under last-minute pressure (P)', 
    'c) Feel constrained by them (P)', 
    'd) Use them to stay organized (J)', 'J', 'P').

question(17, 'When solving conflicts, you:', 
    'a) Look for the most logical solution (T)', 
    'b) Seek harmony and compromise (F)', 
    'c) Analyze pros and cons objectively (T)', 
    'd) Prioritize maintaining relationships (F)', 'T', 'F').

question(18, 'Your workspace is typically:', 
    'a) Neat and organized (J)', 
    'b) Creative but messy (P)', 
    'c) Systematically arranged (J)', 
    'd) Adaptable to current needs (P)', 'J', 'P').

question(19, 'When evaluating an idea, you focus on:', 
    'a) Its logical consistency (T)', 
    'b) Its human impact (F)', 
    'c) Its practical utility (T)', 
    'd) Its ethical implications (F)', 'T', 'F').

question(20, 'Your vacation planning style is:', 
    'a) Detailed itinerary (J)', 
    'b) Spontaneous decisions (P)', 
    'c) Research-heavy preparation (J)', 
    'd) Go where the wind takes you (P)', 'J', 'P').

% Questions 21-40 (Mixed dimensions)
question(21, 'When working on a project, you:', 
    'a) Prefer clear instructions (S)', 
    'b) Enjoy brainstorming sessions (N)', 
    'c) Like established methods (S)', 
    'd) Seek innovative approaches (N)', 'S', 'N').

question(22, 'In social settings, you:', 
    'a) Enjoy being the center of attention (E)', 
    'b) Prefer listening to talking (I)', 
    'c) Feel energized by the crowd (E)', 
    'd) Need time alone afterward (I)', 'E', 'I').

question(23, 'When making important decisions, you:', 
    'a) Weigh the pros and cons carefully (T)', 
    'b) Go with what feels right (F)', 
    'c) Consult objective criteria (T)', 
    'd) Consider people''s feelings (F)', 'T', 'F').

question(24, 'Your approach to life is more:', 
    'a) Planned and structured (J)', 
    'b) Spontaneous and adaptable (P)', 
    'c) Organized and systematic (J)', 
    'd) Flexible and open (P)', 'J', 'P').

question(25, 'You''re more likely to trust:', 
    'a) What you can see and touch (S)', 
    'b) Your intuition and instincts (N)', 
    'c) Concrete evidence (S)', 
    'd) Theoretical frameworks (N)', 'S', 'N').

question(26, 'When working in a team, you:', 
    'a) Take charge and direct others (E)', 
    'b) Contribute quietly from the background (I)', 
    'c) Energize the group (E)', 
    'd) Prefer working alone (I)', 'E', 'I').

question(27, 'In arguments, you value:', 
    'a) Truth and accuracy (T)', 
    'b) Harmony and understanding (F)', 
    'c) Logical consistency (T)', 
    'd) Emotional connection (F)', 'T', 'F').

question(28, 'Your schedule tends to be:', 
    'a) Carefully planned (J)', 
    'b) Loosely structured (P)', 
    'c) Full of appointments (J)', 
    'd) Open to last-minute changes (P)', 'J', 'P').

question(29, 'You''re more interested in:', 
    'a) Current realities (S)', 
    'b) Future possibilities (N)', 
    'c) Practical applications (S)', 
    'd) Theoretical concepts (N)', 'S', 'N').

question(30, 'At work meetings, you:', 
    'a) Speak up frequently (E)', 
    'b) Only speak when you have something important to say (I)', 
    'c) Think before contributing (I)', 
    'd) Enjoy lively discussions (E)', 'E', 'I').

question(31, 'When evaluating a policy, you consider:', 
    'a) Its efficiency and effectiveness (T)', 
    'b) Its impact on people (F)', 
    'c) Its logical basis (T)', 
    'd) Its fairness and compassion (F)', 'T', 'F').

question(32, 'Your approach to tasks is:', 
    'a) Finish them methodically (J)', 
    'b) Jump between multiple projects (P)', 
    'c) Follow a clear plan (J)', 
    'd) Adapt as you go (P)', 'J', 'P').

question(33, 'You''re more likely to notice:', 
    'a) Specific details (S)', 
    'b) Patterns and connections (N)', 
    'c) Concrete facts (S)', 
    'd) Symbolic meanings (N)', 'S', 'N').

question(34, 'In large groups, you usually:', 
    'a) Enjoy interacting with many (E)', 
    'b) Feel drained after a while (I)', 
    'c) Initiate conversations (E)', 
    'd) Seek one-on-one interactions (I)', 'E', 'I').

question(35, 'When helping others, you prefer:', 
    'a) Practical solutions (T)', 
    'b) Emotional support (F)', 
    'c) Logical advice (T)', 
    'd) Personal understanding (F)', 'T', 'F').

question(36, 'Your living space is more:', 
    'a) Neat and orderly (J)', 
    'b) Comfortably messy (P)', 
    'c) Everything in its place (J)', 
    'd) Organized chaos (P)', 'J', 'P').

question(37, 'You''re more interested in:', 
    'a) Actual experiences (S)', 
    'b) Theoretical ideas (N)', 
    'c) Hands-on activities (S)', 
    'd) Abstract concepts (N)', 'S', 'N').

question(38, 'When meeting new people, you:', 
    'a) Easily start conversations (E)', 
    'b) Take time to open up (I)', 
    'c) Enjoy small talk (E)', 
    'd) Prefer meaningful discussions (I)', 'E', 'I').

question(39, 'In making moral judgments, you rely on:', 
    'a) Objective principles (T)', 
    'b) Personal values (F)', 
    'c) Logical analysis (T)', 
    'd) Empathy and compassion (F)', 'T', 'F').

question(40, 'Your work style is more:', 
    'a) Scheduled and disciplined (J)', 
    'b) Flexible and spontaneous (P)', 
    'c) Task-oriented (J)', 
    'd) Opportunity-driven (P)', 'J', 'P').

% Questions 41-60 (Balanced mix)
question(41, 'You prefer jobs that offer:', 
    'a) Clear structure and routine (S)', 
    'b) Variety and new challenges (N)', 
    'c) Practical, tangible results (S)', 
    'd) Creative freedom (N)', 'S', 'N').

question(42, 'After socializing, you typically feel:', 
    'a) Energized and refreshed (E)', 
    'b) Drained and needing alone time (I)', 
    'c) Happy but ready for a break (I)', 
    'd) Wanting more interaction (E)', 'E', 'I').

question(43, 'When criticized, you:', 
    'a) Analyze its validity objectively (T)', 
    'b) Feel hurt personally (F)', 
    'c) Look for constructive elements (T)', 
    'd) Worry about the relationship (F)', 'T', 'F').

question(44, 'Your approach to time management is:', 
    'a) Strict schedules (J)', 
    'b) Whatever feels right in the moment (P)', 
    'c) Detailed planning (J)', 
    'd) Flexible adaptation (P)', 'J', 'P').

question(45, 'You''re more likely to believe:', 
    'a) What you can experience directly (S)', 
    'b) What aligns with your vision (N)', 
    'c) Proven facts (S)', 
    'd) Innovative theories (N)', 'S', 'N').

question(46, 'In classroom settings, you:', 
    'a) Participate actively (E)', 
    'b) Prefer listening (I)', 
    'c) Enjoy discussions (E)', 
    'd) Think before speaking (I)', 'E', 'I').

question(47, 'When evaluating art, you focus on:', 
    'a) Technical skill (T)', 
    'b) Emotional impact (F)', 
    'c) Composition and structure (T)', 
    'd) Personal meaning (F)', 'T', 'F').

question(48, 'Your closet is organized by:', 
    'a) A clear system (J)', 
    'b) Whatever is convenient (P)', 
    'c) Categories and colors (J)', 
    'd) No particular system (P)', 'J', 'P').

question(49, 'You prefer stories that are:', 
    'a) Realistic and factual (S)', 
    'b) Imaginative and symbolic (N)', 
    'c) Based on true events (S)', 
    'd) Full of possibilities (N)', 'S', 'N').

question(50, 'When working on group projects, you:', 
    'a) Take leadership roles (E)', 
    'b) Contribute behind the scenes (I)', 
    'c) Coordinate team efforts (E)', 
    'd) Focus on your individual tasks (I)', 'E', 'I').

question(51, 'When making tough choices, you:', 
    'a) Make pros and cons lists (T)', 
    'b) Go with your heart (F)', 
    'c) Analyze logically (T)', 
    'd) Consider personal values (F)', 'T', 'F').

question(52, 'Your approach to chores is:', 
    'a) Regular schedule (J)', 
    'b) When they need doing (P)', 
    'c) Systematic routine (J)', 
    'd) When you feel like it (P)', 'J', 'P').

question(53, 'You''re more interested in:', 
    'a) How things work (S)', 
    'b) Why things matter (N)', 
    'c) Practical applications (S)', 
    'd) Deeper meanings (N)', 'S', 'N').

question(54, 'At networking events, you:', 
    'a) Work the room (E)', 
    'b) Have a few deep conversations (I)', 
    'c) Meet many people (E)', 
    'd) Feel exhausted afterward (I)', 'E', 'I').

question(55, 'When giving advice, you tend to:', 
    'a) Offer practical solutions (T)', 
    'b) Provide emotional support (F)', 
    'c) Analyze the situation (T)', 
    'd) Relate personally (F)', 'T', 'F').

question(56, 'Your computer files are:', 
    'a) Carefully organized (J)', 
    'b) Wherever you saved them last (P)', 
    'c) In systematic folders (J)', 
    'd) Found via search function (P)', 'J', 'P').

question(57, 'You prefer learning through:', 
    'a) Direct experience (S)', 
    'b) Theoretical models (N)', 
    'c) Hands-on practice (S)', 
    'd) Abstract concepts (N)', 'S', 'N').

question(58, 'In conversations, you:', 
    'a) Enjoy debating ideas (E)', 
    'b) Prefer meaningful one-on-ones (I)', 
    'c) Think out loud (E)', 
    'd) Process internally before speaking (I)', 'E', 'I').

question(59, 'When evaluating ethics, you consider:', 
    'a) Universal principles (T)', 
    'b) Individual circumstances (F)', 
    'c) Logical consistency (T)', 
    'd) Human impact (F)', 'T', 'F').

question(60, 'Your travel style is:', 
    'a) Detailed itinerary (J)', 
    'b) Go with the flow (P)', 
    'c) Research-heavy (J)', 
    'd) Spontaneous adventures (P)', 'J', 'P').

% Questions 61-80 (Balanced mix)
question(61, 'You''re more likely to enjoy:', 
    'a) Realistic fiction (S)', 
    'b) Science fiction/fantasy (N)', 
    'c) Biographies (S)', 
    'd) Philosophical works (N)', 'S', 'N').

question(62, 'At work, you prefer:', 
    'a) Collaborative environments (E)', 
    'b) Independent work (I)', 
    'c) Team brainstorming (E)', 
    'd) Quiet focus time (I)', 'E', 'I').

question(63, 'When solving moral dilemmas, you:', 
    'a) Apply consistent rules (T)', 
    'b) Consider unique situations (F)', 
    'c) Analyze consequences (T)', 
    'd) Empathize with those involved (F)', 'T', 'F').

question(64, 'Your approach to projects is:', 
    'a) Step-by-step completion (J)', 
    'b) Creative exploration (P)', 
    'c) Structured phases (J)', 
    'd) Flexible process (P)', 'J', 'P').

question(65, 'You trust knowledge gained through:', 
    'a) Direct observation (S)', 
    'b) Insight and intuition (N)', 
    'c) Practical experience (S)', 
    'd) Theoretical understanding (N)', 'S', 'N').

question(66, 'In social media, you:', 
    'a) Post frequently (E)', 
    'b) Mostly observe (I)', 
    'c) Enjoy interactions (E)', 
    'd) Prefer private messaging (I)', 'E', 'I').

question(67, 'When evaluating performance, you focus on:', 
    'a) Measurable results (T)', 
    'b) Personal growth (F)', 
    'c) Objective metrics (T)', 
    'd) Individual effort (F)', 'T', 'F').

question(68, 'Your calendar tends to be:', 
    'a) Full of appointments (J)', 
    'b) Mostly empty (P)', 
    'c) Carefully planned (J)', 
    'd) Flexible and open (P)', 'J', 'P').

question(69, 'You prefer teachers who:', 
    'a) Stick to the facts (S)', 
    'b) Explore big ideas (N)', 
    'c) Provide clear examples (S)', 
    'd) Encourage creativity (N)', 'S', 'N').

question(70, 'When meeting friends, you:', 
    'a) Enjoy group activities (E)', 
    'b) Prefer one-on-one time (I)', 
    'c) Like spontaneous gatherings (E)', 
    'd) Plan intimate meetings (I)', 'E', 'I').

question(71, 'When resolving conflicts, you:', 
    'a) Focus on facts and fairness (T)', 
    'b) Seek emotional reconciliation (F)', 
    'c) Look for logical solutions (T)', 
    'd) Prioritize relationship harmony (F)', 'T', 'F').

question(72, 'Your approach to goals is:', 
    'a) Detailed planning (J)', 
    'b) Flexible adaptation (P)', 
    'c) Step-by-step achievement (J)', 
    'd) Opportunity-driven (P)', 'J', 'P').

question(73, 'You''re more interested in:', 
    'a) Current events (S)', 
    'b) Future trends (N)', 
    'c) Practical news (S)', 
    'd) Theoretical discussions (N)', 'S', 'N').

question(74, 'In team sports, you:', 
    'a) Enjoy the social aspect (E)', 
    'b) Focus on your performance (I)', 
    'c) Like the camaraderie (E)', 
    'd) Prefer individual sports (I)', 'E', 'I').

question(75, 'When evaluating policies, you consider:', 
    'a) Efficiency and results (T)', 
    'b) Human impact and fairness (F)', 
    'c) Logical consistency (T)', 
    'd) Compassion and empathy (F)', 'T', 'F').

question(76, 'Your approach to chores is:', 
    'a) Regular schedule (J)', 
    'b) When they can''t be ignored (P)', 
    'c) Systematic completion (J)', 
    'd) When you feel motivated (P)', 'J', 'P').

question(77, 'You prefer entertainment that:', 
    'a) Reflects real life (S)', 
    'b) Explores imaginative worlds (N)', 
    'c) Is factual and documentary (S)', 
    'd) Challenges conventional thinking (N)', 'S', 'N').

question(78, 'In conversations, you tend to:', 
    'a) Speak more than listen (E)', 
    'b) Listen more than speak (I)', 
    'c) Enjoy lively exchanges (E)', 
    'd) Prefer deep discussions (I)', 'E', 'I').

question(79, 'When making rules, you prioritize:', 
    'a) Consistency and fairness (T)', 
    'b) Individual circumstances (F)', 
    'c) Logical basis (T)', 
    'd) Emotional impact (F)', 'T', 'F').

question(80, 'Your approach to life is more:', 
    'a) Organized and planned (J)', 
    'b) Spontaneous and flexible (P)', 
    'c) Structured and predictable (J)', 
    'd) Open to new possibilities (P)', 'J', 'P').

% Questions 81-100 (Final set)
question(81, 'You prefer jobs that involve:', 
    'a) Practical, hands-on work (S)', 
    'b) Conceptual, big-picture thinking (N)', 
    'c) Clear, measurable outcomes (S)', 
    'd) Creative problem-solving (N)', 'S', 'N').

question(82, 'After a long day, you recharge by:', 
    'a) Socializing with friends (E)', 
    'b) Spending time alone (I)', 
    'c) Going out (E)', 
    'd) Quiet reflection (I)', 'E', 'I').

question(83, 'When giving feedback, you:', 
    'a) Focus on objective improvement (T)', 
    'b) Consider the person''s feelings (F)', 
    'c) Provide direct criticism (T)', 
    'd) Sandwich criticism with praise (F)', 'T', 'F').

question(84, 'Your approach to deadlines is:', 
    'a) Meet them early (J)', 
    'b) Work best under pressure (P)', 
    'c) Plan to complete ahead of time (J)', 
    'd) Adapt as deadlines approach (P)', 'J', 'P').

question(85, 'You trust information that comes from:', 
    'a) Personal experience (S)', 
    'b) Theoretical models (N)', 
    'c) Observable evidence (S)', 
    'd) Innovative ideas (N)', 'S', 'N').

question(86, 'In classroom discussions, you:', 
    'a) Frequently participate (E)', 
    'b) Only speak when called on (I)', 
    'c) Enjoy debating ideas (E)', 
    'd) Prefer to listen and process (I)', 'E', 'I').

question(87, 'When evaluating ethics, you rely on:', 
    'a) Universal principles (T)', 
    'b) Situational context (F)', 
    'c) Logical analysis (T)', 
    'd) Emotional intelligence (F)', 'T', 'F').

question(88, 'Your workspace is typically:', 
    'a) Neat and organized (J)', 
    'b) Creatively messy (P)', 
    'c) Efficiently arranged (J)', 
    'd) Adaptable to your current project (P)', 'J', 'P').

question(89, 'You prefer learning methods that are:', 
    'a) Hands-on and practical (S)', 
    'b) Conceptual and theoretical (N)', 
    'c) Based on real examples (S)', 
    'd) Exploring possibilities (N)', 'S', 'N').

question(90, 'When meeting new people, you:', 
    'a) Easily make small talk (E)', 
    'b) Take time to warm up (I)', 
    'c) Enjoy meeting many people (E)', 
    'd) Prefer deeper connections (I)', 'E', 'I').

question(91, 'When solving problems, you:', 
    'a) Look for the most efficient solution (T)', 
    'b) Consider how it affects people (F)', 
    'c) Analyze objectively (T)', 
    'd) Seek harmonious outcomes (F)', 'T', 'F').

question(92, 'Your approach to planning is:', 
    'a) Detailed and thorough (J)', 
    'b) Flexible and adaptable (P)', 
    'c) Structured and organized (J)', 
    'd) Open to change (P)', 'J', 'P').

question(93, 'You''re more interested in:', 
    'a) Current practical realities (S)', 
    'b) Future theoretical possibilities (N)', 
    'c) Concrete facts (S)', 
    'd) Innovative concepts (N)', 'S', 'N').

question(94, 'In group settings, you:', 
    'a) Often take leadership roles (E)', 
    'b) Prefer to follow others'' lead (I)', 
    'c) Energize the group (E)', 
    'd) Work best independently (I)', 'E', 'I').

question(95, 'When evaluating art, you focus on:', 
    'a) Technical execution (T)', 
    'b) Emotional resonance (F)', 
    'c) Composition and skill (T)', 
    'd) Personal meaning (F)', 'T', 'F').

question(96, 'Your approach to daily routines is:', 
    'a) Consistent and structured (J)', 
    'b) Flexible and changing (P)', 
    'c) Carefully planned (J)', 
    'd) Adaptable to mood (P)', 'J', 'P').

question(97, 'You prefer stories that are:', 
    'a) Realistic and factual (S)', 
    'b) Imaginative and symbolic (N)', 
    'c) Based on true events (S)', 
    'd) Full of deeper meanings (N)', 'S', 'N').

question(98, 'When working on projects, you:', 
    'a) Enjoy collaborating (E)', 
    'b) Prefer working alone (I)', 
    'c) Like team brainstorming (E)', 
    'd) Focus best independently (I)', 'E', 'I').

question(99, 'When making tough decisions, you:', 
    'a) Analyze pros and cons (T)', 
    'b) Go with your gut feeling (F)', 
    'c) Look for logical consistency (T)', 
    'd) Consider personal values (F)', 'T', 'F').

question(100, 'Your life is more:', 
    'a) Organized and planned (J)', 
    'b) Spontaneous and flexible (P)', 
    'c) Structured and predictable (J)', 
    'd) Open to new experiences (P)', 'J', 'P').

% Start the test
start_test :-
    reset_answers,
    writeln('=== 100-Question Personality Test ==='),
    writeln('Answer with a, b, c, or d for each question.'),
    writeln('Type "quit." to exit early.'),
    nl,
    ask_question.

% Ask the current question
ask_question :-
    current_question(N),
    (N > 100 -> calculate_results ;
    question(N, Q, A, B, C, D, CatA, CatB),
    format('~nQuestion ~w: ~w~n', [N, Q]),
    format('a) ~w~n', [A]),
    format('b) ~w~n', [B]),
    format('c) ~w~n', [C]),
    format('d) ~w~n', [D]),
    write('Your answer: '),
    read(Answer),
    (Answer == quit -> 
        writeln('Test aborted.'), 
        reset_answers
    ;
    (member(Answer, [a,b,c,d]) ->
        (member(Answer, [a,c]) -> assertz(answered(CatA, 1)) ; true),
        (member(Answer, [b,d]) -> assertz(answered(CatB, 1)) ; true),
        Next is N + 1,
        retract(current_question(_)),
        asserta(current_question(Next)),
        ask_question
    ;
        writeln('Invalid input. Please answer a, b, c, or d.'),
        ask_question
    ))).

% Calculate results by counting preferences
calculate_results :-
    % Count E/I
    findall(_, answered('E', _), EList), length(EList, ECount),
    findall(_, answered('I', _), IList), length(IList, ICount),
    IEPercent is round((ECount / (ECount + ICount)) * 100),
    IPercent is 100 - IEPercent,
    (ECount > ICount -> IE = 'E' ; IE = 'I'),

    % Count S/N
    findall(_, answered('S', _), SList), length(SList, SCount),
    findall(_, answered('N', _), NList), length(NList, NCount),
    SPercent is round((SCount / (SCount + NCount)) * 100),
    NPercent is 100 - SPercent,
    (SCount > NCount -> SN = 'S' ; SN = 'N'),

    % Count T/F
    findall(_, answered('T', _), TList), length(TList, TCount),
    findall(_, answered('F', _), FList), length(FList, FCount),
    TPercent is round((TCount / (TCount + FCount)) * 100),
    FPercent is 100 - TPercent,
    (TCount > FCount -> TF = 'T' ; TF = 'F'),

    % Count J/P
    findall(_, answered('J', _), JList), length(JList, JCount),
    findall(_, answered('P', _), PList), length(PList, PCount),
    JPercent is round((JCount / (JCount + PCount)) * 100),
    PPercent is 100 - JPercent,
    (JCount > PCount -> JP = 'J' ; JP = 'P'),

    % Determine personality type
    atomic_list_concat([IE, SN, TF, JP], PersonalityType),
    personality_type(PersonalityType, Description),

    % Display results
    nl, writeln('=== TEST RESULTS ==='),
    format('Your personality type: ~w~n', [PersonalityType]),
    format('Description: ~w~n~n', [Description]),
    writeln('Dimension Preferences:'),
    format('Extraversion (E) ~w% vs Introversion (I) ~w%: ~w~n', [IEPercent, IPercent, IE]),
    format('Sensing (S) ~w% vs Intuition (N) ~w%: ~w~n', [SPercent, NPercent, SN]),
    format('Thinking (T) ~w% vs Feeling (F) ~w%: ~w~n', [TPercent, FPercent, TF]),
    format('Judging (J) ~w% vs Perceiving (P) ~w%: ~w~n', [JPercent, PPercent, JP]).

% Helper to run the test
run_personality_test :-
    start_test.