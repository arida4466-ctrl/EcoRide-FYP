from pymongo import MongoClient
from datetime import datetime

# MongoDB connection
client = MongoClient("mongodb://localhost:27017/")  # Update if using MongoDB Atlas
db = client["library_db"]
books_col = db["books"]

# Add a new book
def add_book():
    title = input("Enter book title: ")
    author = input("Enter author: ")
    year = input("Enter year: ")

    book = {
        "title": title,
        "author": author,
        "year": year,
        "issued_to": None,
        "issued_on": None
    }

    books_col.insert_one(book)
    print("✅ Book added successfully.")

# View all books
def view_books():
    books = books_col.find()
    for book in books:
        print(f"ID: {book['_id']}")
        print(f"Title: {book['title']}")
        print(f"Author: {book['author']}")
        print(f"Year: {book['year']}")
        status = f"Issued to {book['issued_to']} on {book['issued_on']}" if book['issued_to'] else "Available"
        print(f"Status: {status}")
        print("-" * 40)

# Issue a book
def issue_book():
    book_id = input("Enter book ID to issue: ")
    user = input("Enter user name: ")

    result = books_col.update_one(
        {"_id": ObjectId(book_id), "issued_to": None},
        {"$set": {"issued_to": user, "issued_on": datetime.now()}}
    )

    if result.modified_count > 0:
        print("✅ Book issued successfully.")
    else:
        print("❌ Book not available or ID incorrect.")

# Return a book
def return_book():
    book_id = input("Enter book ID to return: ")

    result = books_col.update_one(
        {"_id": ObjectId(book_id), "issued_to": {"$ne": None}},
        {"$set": {"issued_to": None, "issued_on": None}}
    )

    if result.modified_count > 0:
        print("✅ Book returned successfully.")
    else:
        print("❌ Book not issued or ID incorrect.")

# Delete a book
def delete_book():
    book_id = input("Enter book ID to delete: ")

    result = books_col.delete_one({"_id": ObjectId(book_id)})

    if result.deleted_count > 0:
        print("✅ Book deleted successfully.")
    else:
        print("❌ Book ID not found.")

# Menu
def menu():
    while True:
        print("\n--- Library Management System ---")
        print("1. Add Book")
        print("2. View Books")
        print("3. Issue Book")
        print("4. Return Book")
        print("5. Delete Book")
        print("6. Exit")
        choice = input("Enter your choice: ")

        if choice == "1":
            add_book()
        elif choice == "2":
            view_books()
        elif choice == "3":
            issue_book()
        elif choice == "4":
            return_book()
        elif choice == "5":
            delete_book()
        elif choice == "6":
            print("👋 Exiting...")
            break
        else:
            print("❌ Invalid choice. Try again.")

# Entry point
if __name__ == "__main__":
    from bson.objectid import ObjectId
    menu()
